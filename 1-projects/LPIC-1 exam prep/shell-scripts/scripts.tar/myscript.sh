#!/bin/bash
# comment
# another comment
#
pwd
#
echo
echo "The shell level is: "$SHLVL
echo
#
exit
